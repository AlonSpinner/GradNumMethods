function [T_mat] = rod_explicit(dx,dt)
Ta = 0.5;
hc = 1;
q = 1;
k = 1;
lambda = k * dt/ (dx^2);
L_var = (dx^2+dx*hc*dt+k*dt)/dx

f_TL = @(v1,v2,T_t,T_x) ((Ta*hc + T_x * k/dx + v1 - v2) * dt + T_t)/L_var;
F_TR = @(v1,v2,T_x) T_x + dx/k * (v1 - v2) - dx^2/k;

T_mat = zeros(1/dx,10/dt);
B_mat = diag(ones(1/dx-1,1),1)+diag(ones(1/dx,1))*-2+diag(ones(1/dx-1,1),-1)
B_mat = B_mat(:,2:end-1)
v = zeros(1/dx,1)
for i = 2:2
    for j = 1:1/dx
        v(j) = HW4_2_v(j,i)
    end
    T(i,2:end-1) = T(i-1,1:end) + lambda * T(i-1,1:end)*B_mat;
    T(i,1) = f_TL(v(0),v(1),T(i-1,0),T(i,1))
    T(i,end) = F_TR(v(end-1),v(end),T(i,end-1))
end



end