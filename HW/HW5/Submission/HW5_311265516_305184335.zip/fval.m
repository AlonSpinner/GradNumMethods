function value = fval(x,y)
 value = 1./((x-1).^2+(y-1).^2+(0.1));
end